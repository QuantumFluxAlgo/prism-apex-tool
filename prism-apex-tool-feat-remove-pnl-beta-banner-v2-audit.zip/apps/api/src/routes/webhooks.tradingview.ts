import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import { getConfig } from '../config/env.js';
import { applyGuardWithSizing } from '../lib/guard.js';
import type { TicketInput } from '@prism-apex/rules-apex';
import { store } from '../store.js';
import { alertSchema } from '../schemas/alert.js';
import type { ParseResult } from '../types.js';
import { ctEqual } from '../lib/ctEqual.js';

export function normalizeSymbol(sym: string): string {
  return sym.replace(/\d+!$/, '');
}

const rawPayload = z.object({
  symbol: z.string(),
  side: z.enum(['BUY', 'SELL']),
  entry: z.coerce.number(),
  stop: z.coerce.number(),
  target: z.coerce.number(),
  qty: z.coerce.number().int().positive().optional(),
  accountId: z.string().optional(),
  meta: z.record(z.unknown()).optional(),
});

const normalizedPayload = rawPayload.extend({
  timestampUtc: z.string(),
});

const payloadSchema = z.union([normalizedPayload, rawPayload]);

export async function tradingviewWebhookRoutes(app: FastifyInstance) {
  app.post('/tradingview', async (req, reply) => {
    const cfg = getConfig();
    const secret = cfg.webhook.tradingviewSecret;
    if (!secret) {
      return reply.code(422).send({ error: 'webhook disabled: secret not configured' });
    }
    const headerSecret = req.headers['x-webhook-secret'];
    if (typeof headerSecret !== 'string' || !ctEqual(headerSecret, secret)) {
      return reply.code(401).send({ error: 'unauthorized' });
    }

    const parsed = payloadSchema.safeParse(req.body);
    if (!parsed.success) {
      return reply.code(400).send({ error: 'invalid payload' });
    }
    const p = parsed.data;
    const ticket: TicketInput = {
      symbol: normalizeSymbol(p.symbol),
      side: p.side === 'BUY' ? 'long' : 'short',
      entry: p.entry,
      stop: p.stop,
      target: p.target,
      timestampUtc: 'timestampUtc' in p ? p.timestampUtc : undefined,
      meta: p.meta,
    };

    const decision = await applyGuardWithSizing({
      ...ticket,
      accountId: (p as any).accountId,
      qty: (p as any).qty,
    });
    if (!decision.accepted) {
      req.log.warn({ rr: decision.rr, reasons: decision.reasons }, 'tradingview webhook rejected');
      return reply.code(422).send({
        accepted: false,
        rr: decision.rr,
        reasons: decision.reasons,
        sizing: decision.sizing,
      });
    }

    let queuedId: string | undefined;
    const maybeAlert = alertSchema.safeParse(req.body);
    if (maybeAlert.success) {
      queuedId = store.enqueueAlert(maybeAlert.data as ParseResult).id;
    }

    const res: { accepted: true; rr: number; sizing?: any; queuedId?: string } = {
      accepted: true,
      rr: decision.rr,
    };
    if (decision.sizing) res.sizing = decision.sizing;
    if (queuedId) res.queuedId = queuedId;
    return reply.code(202).send(res);
  });
}
