import React from 'react';

type TooltipProps = {
  text: string;
  children: React.ReactNode;
  className?: string;
};

/**
 * Lightweight tooltip wrapper using the native `title` attribute until we adopt a richer UI kit.
 */
export function Tooltip({ text, children, className = '' }: TooltipProps) {
  return (
    <span title={text} className={['inline-flex items-center', className].filter(Boolean).join(' ')}>
      {children}
    </span>
  );
}


export default Tooltip;
