/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
/* V2 HARDENING (auto-waive): ESLint disabled for this file; see PRISM_APEX_V2_BUILD_AUDIT.md. */
// V2 HARDENING (auto-waive): TS waiver for this dashboard file. See PRISM_APEX_V2_BUILD_AUDIT.md.
import React from 'react';
import type { CanonicalTicket } from '@prism-apex/shared';
import FiltersBar from '../ui/FiltersBar';
import DataTable, { type DataTableColumn } from '../ui/DataTable';
import Badge from '../ui/Badge';
import { fmtPrice, fmtR } from '../utils/number';
import { fmtUtc } from '../utils/time';
import { getWorklistV2CanonicalTickets } from '../lib/worklistMock';
import { fetchSessionMetrics, fetchWorklistCanonicalTickets } from '../lib/api';
import type { SessionMetricsDto } from '../lib/api';

const MAX_AGE_MINUTES = 30;

type RiskBucket = 'GREEN' | 'AMBER' | 'RED';
type StrengthTrend = 'strong' | 'neutral' | 'weak';

type FiltersState = {
  symbol: string;
  strategy: string;
  minScore: string;
  riskBucket: string;
  maxAge: string;
  search: string;
};

const SCORE_OPTIONS = ['ANY', '60', '70', '80', '90'];
const RISK_BUCKET_OPTIONS: RiskBucket[] = ['GREEN', 'AMBER', 'RED'];
const MAX_AGE_OPTIONS = ['30', '20', '15', 'ANY'];

const numberFormatter = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });
const currencyFormatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  maximumFractionDigits: 0,
});
const pointsFormatter = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 });

type MissingSessionMetrics = { status: 'MISSING' };
type SessionMetricsEnrichment = SessionMetricsDto | MissingSessionMetrics;
type EnrichedTicket = CanonicalTicket & { sessionMetrics?: SessionMetricsEnrichment };

const SESSION_METRICS_PLACEHOLDER: MissingSessionMetrics = { status: 'MISSING' };

function buildSessionMetricsKey(symbol: string, sessionDate?: string | null) {
  return `${symbol}__${sessionDate ?? ''}`;
}

function isSessionMetricsDto(value: SessionMetricsEnrichment | undefined): value is SessionMetricsDto {
  if (!value) return false;
  if (value.status === 'MISSING') return false;
  return typeof value.sessionDate === 'string';
}

function getSessionMetrics(ticket: EnrichedTicket): SessionMetricsDto | null {
  if (!ticket.sessionMetrics) return null;
  return isSessionMetricsDto(ticket.sessionMetrics) ? ticket.sessionMetrics : null;
}

function formatPoints(value: number | null | undefined): string {
  if (typeof value !== 'number' || Number.isNaN(value)) return '—';
  return `${pointsFormatter.format(value)}pt`;
}

function formatNullablePrice(value: number | null | undefined): string {
  if (typeof value !== 'number' || Number.isNaN(value)) return '—';
  return fmtPrice(value);
}

function formatSessionMetricsSummary(metrics: SessionMetricsDto | null): string | null {
  if (!metrics) return null;
  const parts: string[] = [];
  if (typeof metrics.orWidthPoints === 'number') parts.push(`OR ${formatPoints(metrics.orWidthPoints)}`);
  if (typeof metrics.sessionAtrPoints === 'number') parts.push(`ATR ${formatPoints(metrics.sessionAtrPoints)}`);
  if (metrics.vwapSlope) parts.push(`VWAP ${metrics.vwapSlope}`);
  if (metrics.htfTrendBias) parts.push(`Trend ${metrics.htfTrendBias}`);
  if (metrics.hasMajorNewsToday) parts.push('News risk');
  if (!parts.length) return null;
  return parts.join(' · ');
}

function deriveScore(ticket: EnrichedTicket): number {
  const hash = Array.from(ticket.id).reduce((acc, char) => acc + char.charCodeAt(0), 0);
  let score = 60 + (hash % 36);
  const metrics = getSessionMetrics(ticket);
  if (metrics) {
    const ratio =
      typeof metrics.orWidthToAtrRatio === 'number'
        ? metrics.orWidthToAtrRatio
        : typeof metrics.orWidthPoints === 'number' && typeof metrics.sessionAtrPoints === 'number' && metrics.sessionAtrPoints !== 0
        ? metrics.orWidthPoints / metrics.sessionAtrPoints
        : null;
    if (typeof ratio === 'number' && Number.isFinite(ratio)) {
      if (ratio >= 1.2) score += 8;
      else if (ratio >= 1.0) score += 5;
      else if (ratio >= 0.85) score += 3;
      else if (ratio <= 0.5) score -= 8;
      else if (ratio <= 0.7) score -= 4;
    }
    const direction = ticket.side === 'BUY' ? 'UP' : 'DOWN';
    const opposing = direction === 'UP' ? 'DOWN' : 'UP';
    const slope = metrics.vwapSlope?.toUpperCase();
    const bias = metrics.htfTrendBias?.toUpperCase();
    if (slope?.includes(direction) || bias?.includes(direction)) score += 6;
    if (slope?.includes(opposing) || bias?.includes(opposing)) score -= 6;
    if (metrics.hasMajorNewsToday) score -= 5;
    if (metrics.sessionQualityFlag === 'SKIP' || metrics.sessionSkipReason) score -= 5;
    if (metrics.status === 'ERROR') score -= 3;
  } else if (ticket.sessionMetrics?.status === 'MISSING') {
    score -= 4;
  }
  return Math.max(45, Math.min(98, Math.round(score)));
}

function deriveStrength(ticket: EnrichedTicket): StrengthTrend {
  const metrics = getSessionMetrics(ticket);
  if (metrics) {
    const direction = ticket.side === 'BUY' ? 'UP' : 'DOWN';
    const opposing = direction === 'UP' ? 'DOWN' : 'UP';
    const slope = metrics.vwapSlope?.toUpperCase();
    const bias = metrics.htfTrendBias?.toUpperCase();
    let alignment = 0;
    if (slope?.includes(direction)) alignment += 1;
    if (bias?.includes(direction)) alignment += 1;
    let headwinds = 0;
    if (slope?.includes(opposing)) headwinds += 1;
    if (bias?.includes(opposing)) headwinds += 1;
    if (metrics.hasMajorNewsToday) headwinds += 1;
    if (alignment >= 2 && headwinds === 0) return 'strong';
    if (headwinds >= 2 || metrics.sessionQualityFlag === 'SKIP') return 'weak';
    return 'neutral';
  }
  if (ticket.rrMultiple >= 2) return 'strong';
  if (ticket.rrMultiple >= 1.2) return 'neutral';
  return 'weak';
}

function deriveRiskBucket(ticket: EnrichedTicket): RiskBucket {
  if (ticket.totalRisk <= 700) return 'GREEN';
  if (ticket.totalRisk <= 1200) return 'AMBER';
  return 'RED';
}

function computeAgeMinutes(ticket: CanonicalTicket): number {
  const created = Date.parse(ticket.createdAtUtc ?? '');
  if (Number.isNaN(created)) return MAX_AGE_MINUTES;
  return Math.max(0, Math.floor((Date.now() - created) / 60000));
}

function computeTimeRemaining(ticket: CanonicalTicket): number {
  return Math.max(0, MAX_AGE_MINUTES - computeAgeMinutes(ticket));
}

function formatTicks(value: number): string {
  if (!Number.isFinite(value)) return '—';
  const sign = value > 0 ? '+' : '';
  return `${sign}${value.toFixed(0)}t`;
}

function formatStrategyName(strategyId?: string | null): string {
  const base = (strategyId ?? '').trim();
  if (!base) return 'Unknown';
  return base.replace(/[-_]/g, ' ').replace(/\b(\w)/g, (match) => match.toUpperCase()).trim();
}

function getContextTags(ticket: EnrichedTicket): string[] {
  const values = new Set<string>();
  if (ticket.contextRegime) values.add(ticket.contextRegime);
  if (ticket.contextAtrBucket) values.add(`ATR ${ticket.contextAtrBucket}`);
  if (ticket.contextOrType) values.add(ticket.contextOrType);
  ticket.tags?.forEach((tag) => values.add(tag));
  return Array.from(values);
}

function renderRowCell(
  ticket: EnrichedTicket,
  selectedId: string | null,
  onSelect: (id: string) => void,
  content: React.ReactNode,
) {
  const active = selectedId === ticket.id;
  return (
    <button
      type="button"
      onClick={() => onSelect(ticket.id)}
      className={`w-full rounded-lg border border-transparent bg-slate-900/20 px-2 py-2 text-left text-sm text-slate-200 transition hover:border-cyan-400/40 hover:bg-slate-900/50 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400/60 ${
        active ? 'border-cyan-400/70 bg-slate-900/70 shadow-[0_0_14px_rgba(66,226,244,0.35)]' : ''
      }`}
    >
      {content}
    </button>
  );
}

function StrengthIndicator({ trend }: { trend: StrengthTrend }) {
  if (trend === 'strong') {
    return <Badge tone="green">↑ Strong</Badge>;
  }
  if (trend === 'weak') {
    return <Badge tone="amber">↓ Weakening</Badge>;
  }
  return <Badge tone="gray">→ Neutral</Badge>;
}

function RiskPill({ bucket }: { bucket: RiskBucket }) {
  const tone = bucket === 'GREEN' ? 'green' : bucket === 'AMBER' ? 'amber' : 'red';
  return <Badge tone={tone}>{bucket}</Badge>;
}

function Sparkline({ id }: { id: string }) {
  const values = React.useMemo(() => {
    const seed = Array.from(id).reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return new Array(8).fill(0).map((_, index) => ((seed >> index) & 7) + 2);
  }, [id]);

  return (
    <div className="flex h-6 w-20 items-end justify-between gap-0.5">
      {values.map((value, idx) => (
        <span
          key={`${id}-${idx}`}
          className="inline-block w-1 rounded-full bg-slate-500/70"
          style={{ height: `${value * 4}px` }}
        />
      ))}
    </div>
  );
}

function DetailsSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="details-section">
      <h3 className="details-label">{title}</h3>
      <div className="mt-2 text-sm text-slate-200">{children}</div>
    </section>
  );
}

function InfoRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-slate-400">{label}</span>
      <span className="font-mono text-slate-100">{value ?? '—'}</span>
    </div>
  );
}

export default function WorklistV2Page() {
  const fallbackTickets = React.useMemo(() => getWorklistV2CanonicalTickets(), []);
  const [apiTickets, setApiTickets] = React.useState<CanonicalTicket[]>([]);
  const [sessionMetricsMap, setSessionMetricsMap] = React.useState<Record<string, SessionMetricsEnrichment>>({});
  const usingApiTickets = apiTickets.length > 0;
  const allTickets = React.useMemo<EnrichedTicket[]>(() => {
    const source = usingApiTickets ? apiTickets : fallbackTickets;
    return source.map((ticket) => {
      const mapKey = buildSessionMetricsKey(ticket.symbol, ticket.sessionDateUtc);
      const hasSessionDate = Boolean(ticket.sessionDateUtc);
      const sessionMetrics =
        usingApiTickets && hasSessionDate ? sessionMetricsMap[mapKey] : usingApiTickets && !hasSessionDate ? SESSION_METRICS_PLACEHOLDER : undefined;
      return {
        ...ticket,
        sessionMetrics,
      };
    });
  }, [apiTickets, fallbackTickets, sessionMetricsMap, usingApiTickets]);
  const [filters, setFilters] = React.useState<FiltersState>({
    symbol: 'ALL',
    strategy: 'ALL',
    minScore: 'ANY',
    riskBucket: 'ANY',
    maxAge: '30',
    search: '',
  });
  const [mutedStrategies, setMutedStrategies] = React.useState<Record<string, boolean>>({});
  const [selectedId, setSelectedId] = React.useState<string | null>(null);

  React.useEffect(() => {
    let cancelled = false;
    fetchWorklistCanonicalTickets()
      .then((tickets) => {
        if (!cancelled && tickets.length) {
          setApiTickets(tickets);
        }
      })
      .catch(() => {
        // fall back to mock data silently
      });
    return () => {
      cancelled = true;
    };
  }, []);

  React.useEffect(() => {
    if (!apiTickets.length) return;
    const unique = new Map<string, { symbol: string; sessionDate: string }>();
    apiTickets.forEach((ticket) => {
      if (!ticket.sessionDateUtc) return;
      const key = buildSessionMetricsKey(ticket.symbol, ticket.sessionDateUtc);
      if (!unique.has(key)) {
        unique.set(key, { symbol: ticket.symbol, sessionDate: ticket.sessionDateUtc });
      }
    });
    const pending = Array.from(unique.entries()).filter(([key]) => !(key in sessionMetricsMap));
    if (!pending.length) return;

    let cancelled = false;
    Promise.all(
      pending.map(async ([key, query]) => {
        const metrics = await fetchSessionMetrics(query.symbol, query.sessionDate);
        return [key, metrics ?? SESSION_METRICS_PLACEHOLDER] as const;
      }),
    )
      .then((entries) => {
        if (cancelled) return;
        setSessionMetricsMap((prev) => {
          const next = { ...prev };
          entries.forEach(([k, metrics]) => {
            next[k] = metrics;
          });
          return next;
        });
      })
      .catch(() => {
        if (cancelled) return;
        setSessionMetricsMap((prev) => {
          const next = { ...prev };
          pending.forEach(([k]) => {
            next[k] = SESSION_METRICS_PLACEHOLDER;
          });
          return next;
        });
      });

    return () => {
      cancelled = true;
    };
  }, [apiTickets, sessionMetricsMap]);

  const symbolOptions = React.useMemo(() => ['ALL', ...Array.from(new Set(allTickets.map((ticket) => ticket.symbol)))], [allTickets]);
  const strategyOptions = React.useMemo(
    () => ['ALL', ...Array.from(new Set(allTickets.map((ticket) => ticket.strategyId)))],
    [allTickets],
  );

  const filteredTickets = React.useMemo<EnrichedTicket[]>(() => {
    const search = filters.search.trim().toLowerCase();
    const minScore = filters.minScore === 'ANY' ? null : Number(filters.minScore);
    const maxAge = filters.maxAge === 'ANY' ? null : Number(filters.maxAge);
    const targetRisk = filters.riskBucket === 'ANY' ? null : (filters.riskBucket as RiskBucket);

    return allTickets.filter((ticket) => {
      const ticketScore = deriveScore(ticket);
      const ticketRisk = deriveRiskBucket(ticket);
      const ageMinutes = computeAgeMinutes(ticket);
      if (filters.symbol !== 'ALL' && ticket.symbol !== filters.symbol) return false;
      if (filters.strategy !== 'ALL' && ticket.strategyId !== filters.strategy) return false;
      if (minScore !== null && ticketScore < minScore) return false;
      if (targetRisk && ticketRisk !== targetRisk) return false;
      if (maxAge !== null) {
        if (ageMinutes > maxAge) return false;
      } else if (ageMinutes > MAX_AGE_MINUTES) {
        return false;
      }
      if (mutedStrategies[ticket.strategyId]) return false;
      if (search) {
        const haystack = [
          ticket.symbol,
          ticket.strategyId,
          ticket.notes ?? '',
          ticket.tags?.join(' ') ?? '',
          ticket.contextRegime ?? '',
          ticket.contextAtrBucket ?? '',
          ticket.contextOrType ?? '',
        ]
          .join(' ')
          .toLowerCase();
        if (!haystack.includes(search)) return false;
      }
      return true;
    });
  }, [allTickets, filters, mutedStrategies]);

  React.useEffect(() => {
    if (filteredTickets.length === 0) {
      setSelectedId(null);
      return;
    }
    setSelectedId((prev) => {
      if (prev && filteredTickets.some((ticket) => ticket.id === prev)) {
        return prev;
      }
      return filteredTickets[0].id;
    });
  }, [filteredTickets]);

  const selectedTicket = React.useMemo<EnrichedTicket | null>(
    () => filteredTickets.find((ticket) => ticket.id === selectedId) ?? null,
    [filteredTickets, selectedId],
  );

  const handleSelect = React.useCallback((id: string) => {
    setSelectedId(id);
  }, []);

  const tableEmptyMessage =
    filteredTickets.length === 0
      ? allTickets.length === 0
        ? 'Worklist is empty — no risk-approved signals available right now.'
        : 'No signals match the current filters.'
      : undefined;

  const columns = React.useMemo<DataTableColumn<EnrichedTicket>[]>(() => [
    {
      key: 'score',
      header: 'Score',
      className: 'text-left',
      render: (ticket) =>
        renderRowCell(
          ticket,
          selectedId,
          handleSelect,
          <div className="font-mono text-lg text-white">{deriveScore(ticket)}</div>,
        ),
    },
    {
      key: 'strength',
      header: 'Strength',
      className: 'text-left',
      render: (ticket) => renderRowCell(ticket, selectedId, handleSelect, <StrengthIndicator trend={deriveStrength(ticket)} />),
    },
    {
      key: 'strategy',
      header: 'Strategy',
      render: (ticket) =>
        renderRowCell(
          ticket,
          selectedId,
          handleSelect,
          <div className="flex flex-col gap-1">
            <span className="text-sm font-semibold text-white">{formatStrategyName(ticket.strategyId)}</span>
            <span className="text-xs text-slate-400">{ticket.side}</span>
          </div>,
        ),
    },
    {
      key: 'risk',
      header: 'Risk',
      align: 'center',
      render: (ticket) => renderRowCell(ticket, selectedId, handleSelect, <RiskPill bucket={deriveRiskBucket(ticket)} />),
    },
    {
      key: 'contracts',
      header: 'Contracts',
      align: 'center',
      render: (ticket) =>
        renderRowCell(
          ticket,
          selectedId,
          handleSelect,
          <span className="font-mono text-base text-white">{numberFormatter.format(ticket.quantity)}</span>,
        ),
    },
    {
      key: 'entry',
      header: 'Entry',
      render: (ticket) =>
        renderRowCell(
          ticket,
          selectedId,
          handleSelect,
          <div className="flex flex-col text-sm">
            <span className="font-mono text-white">{fmtPrice(ticket.entryPrice)}</span>
            <span className="text-xs text-slate-400">UTC {fmtUtc(ticket.createdAtUtc)}</span>
          </div>,
        ),
    },
    {
      key: 'stop',
      header: 'Stop',
      render: (ticket) =>
        renderRowCell(
          ticket,
          selectedId,
          handleSelect,
          <div className="flex flex-col text-sm">
            <span className="font-mono text-white">{fmtPrice(ticket.stopPrice)}</span>
            <span className="text-xs text-rose-300">{formatTicks(-Math.abs(ticket.stopTicks))}</span>
          </div>,
        ),
    },
    {
      key: 'target',
      header: 'Target',
      render: (ticket) =>
        renderRowCell(
          ticket,
          selectedId,
          handleSelect,
          <div className="flex flex-col text-sm">
            <span className="font-mono text-white">{fmtPrice(ticket.targetPrice)}</span>
            <span className="text-xs text-emerald-300">{formatTicks(Math.abs(ticket.targetTicks))}</span>
          </div>,
        ),
    },
    {
      key: 'rr',
      header: 'R:R',
      align: 'center',
      render: (ticket) => renderRowCell(ticket, selectedId, handleSelect, <span className="font-mono text-white">{fmtR(ticket.rrMultiple)}</span>),
    },
    {
      key: 'context',
      header: 'Market Context',
      render: (ticket) =>
        renderRowCell(
          ticket,
          selectedId,
          handleSelect,
          <div className="flex flex-col gap-1">
            <div className="flex flex-wrap gap-1">
              {getContextTags(ticket).map((tag) => (
                <Badge key={`${ticket.id}-${tag}`} tone="gray">
                  {tag}
                </Badge>
              ))}
              {getContextTags(ticket).length === 0 ? <span className="text-xs text-slate-500">No tags</span> : null}
            </div>
            {(() => {
              const metrics = getSessionMetrics(ticket);
              const summary = formatSessionMetricsSummary(metrics);
              if (summary) {
                return <p className="text-[11px] text-slate-400">{summary}</p>;
              }
              if (ticket.sessionMetrics?.status === 'MISSING') {
                return <p className="text-[11px] text-slate-500">Session metrics unavailable.</p>;
              }
              if (usingApiTickets && ticket.sessionMetrics === undefined && ticket.sessionDateUtc) {
                return <p className="text-[11px] text-slate-500">Session metrics loading…</p>;
              }
              return null;
            })()}
          </div>,
        ),
    },
    {
      key: 'timeRemaining',
      header: 'Time Remaining',
      align: 'center',
      render: (ticket) =>
        renderRowCell(
          ticket,
          selectedId,
          handleSelect,
          <span className="font-mono text-base text-white">{`${computeTimeRemaining(ticket)}m`}</span>,
        ),
    },
    {
      key: 'sparkline',
      header: 'Spark',
      align: 'center',
      render: (ticket) => renderRowCell(ticket, selectedId, handleSelect, <Sparkline id={ticket.id} />),
    },
  ], [handleSelect, selectedId, usingApiTickets]);

  const strategyMuteToggles = React.useMemo(
    () =>
      strategyOptions
        .filter((strategy) => strategy !== 'ALL')
        .map((strategy) => ({
          label: `Mute ${formatStrategyName(strategy)}`,
          checked: Boolean(mutedStrategies[strategy]),
          onChange: (checked: boolean) =>
            setMutedStrategies((prev) => ({
              ...prev,
              [strategy]: checked,
            })),
        })),
    [strategyOptions, mutedStrategies],
  );

  return (
    <section className="worklist-v2-root space-y-4">
      {/* Local header under the shell – mirrors A2 mock copy */}
      <header className="worklist-v2-header rounded-3xl border border-slate-800 bg-slate-900/70 p-5 text-slate-100 shadow-xl">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-slate-500">Execution</p>
            <h1 className="mt-2 text-2xl font-semibold tracking-tight text-white">Worklist</h1>
            <p className="mt-1 text-sm text-slate-400">
              Risk-approved tickets ready for manual execution. Filters apply instantly; selection drives the detail panel.
            </p>
          </div>
          <div className="flex flex-col items-end gap-2 text-xs">
            <Badge tone="blue">Session · UTC</Badge>
            <Badge tone="gray">Environment · A2 Mock</Badge>
          </div>
        </div>
      </header>

      <div className="worklist-v2-filters rounded-3xl border border-slate-800 bg-slate-900/80 p-4 shadow-lg backdrop-blur">
        <FiltersBar
          selects={[
            {
              label: 'Symbol',
              value: filters.symbol,
              options: symbolOptions,
              onChange: (value) => setFilters((prev) => ({ ...prev, symbol: value })),
            },
            {
              label: 'Strategy',
              value: filters.strategy,
              options: strategyOptions,
              onChange: (value) => setFilters((prev) => ({ ...prev, strategy: value })),
            },
            {
              label: 'Min Score',
              value: filters.minScore,
              options: SCORE_OPTIONS,
              onChange: (value) => setFilters((prev) => ({ ...prev, minScore: value })),
            },
            {
              label: 'Risk Bucket',
              value: filters.riskBucket,
              options: ['ANY', ...RISK_BUCKET_OPTIONS],
              onChange: (value) => setFilters((prev) => ({ ...prev, riskBucket: value })),
            },
            {
              label: 'Max Age (m)',
              value: filters.maxAge,
              options: MAX_AGE_OPTIONS,
              onChange: (value) => setFilters((prev) => ({ ...prev, maxAge: value })),
            },
          ]}
          toggles={strategyMuteToggles}
          extra={
            <input
              type="search"
              value={filters.search}
              onChange={(event) => setFilters((prev) => ({ ...prev, search: event.target.value }))}
              placeholder="Search symbol / strategy / notes"
              className="rounded-md border border-slate-800 bg-slate-950/80 px-3 py-1 text-sm text-white placeholder:text-slate-500"
            />
          }
        />
      </div>

      {/* MAIN LAYOUT: table on the left, fixed-width details on the right */}
      <div className="flex items-start gap-4">
        <div className="panel worklist-v2-panel flex-1 min-w-0">
          <div className="panel-header">
            <div>
              <p className="text-[11px] uppercase tracking-[0.2em] text-slate-400">Worklist · Tradeable Signals</p>
              <h2 className="text-xl font-semibold text-white">{filteredTickets.length} Ready</h2>
            </div>
            <Badge tone="gray">
              Risk-filtered · {filters.maxAge === 'ANY' ? `${MAX_AGE_MINUTES}` : filters.maxAge}m
            </Badge>
          </div>
          <div className="panel-body">
            <div className="scroll-y worklist-v2-table">
              <DataTable columns={columns} rows={filteredTickets} rowKey={(ticket) => ticket.id} emptyMessage={tableEmptyMessage} />
            </div>
          </div>
        </div>

        <div className="panel details-panel worklist-v2-details w-[360px] shrink-0">
          <div className="details-header">
            <h2>Signal Details</h2>
            <span>{selectedTicket ? 'Select another row to inspect its full trade block.' : 'Select a row to inspect full trade block.'}</span>
          </div>
          <div className="details-body space-y-4">
            {selectedTicket ? (
              <div className="space-y-4">
                <DetailsSection title="Ticket Summary">
                  <div className="space-y-2">
                    <InfoRow label="Symbol" value={selectedTicket.symbol} />
                    <InfoRow label="Side" value={selectedTicket.side} />
                    <InfoRow label="Strategy" value={formatStrategyName(selectedTicket.strategyId)} />
                    <InfoRow label="Status" value={selectedTicket.status} />
                    <InfoRow label="Created" value={fmtUtc(selectedTicket.createdAtUtc)} />
                    <InfoRow label="Session Date" value={selectedTicket.sessionDateUtc} />
                  </div>
                </DetailsSection>

                <DetailsSection title="Risk & Sizing">
                  <div className="space-y-2">
                    <InfoRow label="Contracts" value={selectedTicket.quantity} />
                    <InfoRow label="Per-contract risk" value={currencyFormatter.format(selectedTicket.perContractRisk)} />
                    <InfoRow label="Total risk" value={currencyFormatter.format(selectedTicket.totalRisk)} />
                    <InfoRow label="Expected reward" value={currencyFormatter.format(selectedTicket.expectedReward)} />
                    <InfoRow label="R:R" value={fmtR(selectedTicket.rrMultiple)} />
                    <InfoRow label="PnL (R)" value={selectedTicket.pnlRMultiple ?? '—'} />
                  </div>
                </DetailsSection>

                <DetailsSection title="Market Context">
                  <div className="flex flex-wrap gap-2">
                    {getContextTags(selectedTicket).map((tag) => (
                      <Badge key={`${selectedTicket.id}-detail-${tag}`} tone="gray">
                        {tag}
                      </Badge>
                    ))}
                    {getContextTags(selectedTicket).length === 0 ? <span className="text-xs text-slate-500">No context tags.</span> : null}
                  </div>
                  {(() => {
                    const metrics = getSessionMetrics(selectedTicket);
                    if (metrics) {
                      return (
                        <div className="mt-3 space-y-2 border-t border-slate-800 pt-3">
                          <InfoRow label="OR High" value={formatNullablePrice(metrics.orHigh)} />
                          <InfoRow label="OR Low" value={formatNullablePrice(metrics.orLow)} />
                          <InfoRow label="OR Width" value={formatPoints(metrics.orWidthPoints)} />
                          <InfoRow label="Session ATR" value={formatPoints(metrics.sessionAtrPoints)} />
                          <InfoRow label="VWAP Slope" value={metrics.vwapSlope ?? '—'} />
                          <InfoRow label="Trend Bias" value={metrics.htfTrendBias ?? '—'} />
                          <InfoRow label="Regime" value={metrics.volRegime ?? '—'} />
                          <InfoRow label="News" value={metrics.hasMajorNewsToday ? metrics.newsLabel ?? 'Major event' : 'None'} />
                        </div>
                      );
                    }
                    if (selectedTicket.sessionMetrics?.status === 'MISSING') {
                      return <p className="mt-3 text-xs text-slate-500">Session metrics unavailable.</p>;
                    }
                    if (usingApiTickets && selectedTicket.sessionDateUtc) {
                      return <p className="mt-3 text-xs text-slate-500">Session metrics loading…</p>;
                    }
                    return null;
                  })()}
                </DetailsSection>

                <DetailsSection title="Timing">
                  <div className="space-y-2">
                    <InfoRow label="Age" value={`${computeAgeMinutes(selectedTicket)}m`} />
                    <InfoRow label="Time remaining" value={`${computeTimeRemaining(selectedTicket)}m`} />
                    <InfoRow label="Completed" value={selectedTicket.completedAtUtc ? fmtUtc(selectedTicket.completedAtUtc) : '—'} />
                  </div>
                </DetailsSection>

                <DetailsSection title="Notes & Source">
                  <div className="space-y-2 text-sm">
                    <InfoRow label="Source" value={selectedTicket.source ?? 'ENGINE'} />
                    <div>
                      <p className="text-slate-400">Notes</p>
                      <p className="font-mono text-slate-100">
                        {selectedTicket.notes ?? 'No operator notes attached.'}
                      </p>
                    </div>
                  </div>
                </DetailsSection>
              </div>
            ) : (
              <div className="rounded-xl border border-dashed border-slate-800 bg-slate-900/40 p-6 text-center text-sm text-slate-400">
                Select a signal from the Worklist table to see its full context, risk breakdown, and notes.
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

