#!/usr/bin/env bash
set -e

echo "=== PRISM APEX — GENERATING STRATEGY LAB MOCK (PORT 3200, NO NPM) ==="

rm -rf strategy-lab-mock
mkdir strategy-lab-mock
cd strategy-lab-mock

cat > index.html << 'EON'
<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
  <meta charset="UTF-8" />
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@300;400;500;600&display=swap" rel="stylesheet" />
  <title>Strategy Lab – Prism Apex</title>

  <style>
    body { font-family: "Space Grotesk", sans-serif; }
    .mono { font-family: "IBM Plex Mono", monospace; }

    .theme-dark {
      --bg: #0F1116;
      --bg-panel: #1A1D23;
      --bg-header: #13161C;
      --text: #E7ECF3;
      --text-secondary: #A1A8B5;
      --text-muted: #626975;
      --border: rgba(255,255,255,0.08);
      --accent: #42E2F4;
      --accent-soft: rgba(66,226,244,0.18);
      --safer: #22C55E;
      --riskier: #F97373;
      --caution: #FBBF24;
    }
    .theme-light {
      --bg: #F6F8FA;
      --bg-panel: #FFFFFF;
      --bg-header: #E9ECEF;
      --text: #0F1116;
      --text-secondary: #444;
      --text-muted: #777;
      --border: rgba(0,0,0,0.1);
      --accent: #0AA4BE;
      --accent-soft: rgba(10,164,190,0.18);
      --safer: #16A34A;
      --riskier: #DC2626;
      --caution: #EAB308;
    }

    body {
      background: var(--bg);
      color: var(--text);
      transition: background 0.25s ease, color 0.25s ease;
    }

    .config-active {
      box-shadow: 0 0 0 1px var(--accent-soft), 0 0 0 1px var(--accent), 0 10px 25px rgba(15,23,42,0.7);
      border-color: var(--accent);
    }

    .impact-pill {
      border-radius: 9999px;
      padding: 2px 8px;
      font-size: 10px;
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }

    .impact-safer {
      background: rgba(34,197,94,0.1);
      color: var(--safer);
    }

    .impact-riskier {
      background: rgba(248,113,113,0.12);
      color: var(--riskier);
    }

    .impact-neutral {
      background: rgba(148,163,184,0.14);
      color: var(--text-secondary);
    }

    @keyframes subtlePulse {
      0% { opacity: 0.85; }
      50% { opacity: 1; }
      100% { opacity: 0.85; }
    }
  </style>
</head>

<body class="theme-dark h-full">

<script>
// Theme toggle
function toggleTheme() {
  const b = document.body;
  b.classList.toggle("theme-dark");
  b.classList.toggle("theme-light");
}

// ---------- Fake data generators ----------

function fakeConfigSets() {
  return {
    activeId: "ORR_ES_D1",
    configs: [
      { id: "ORR_ES_D1", label: "ORR_ES_D1", note: "Live baseline", active: true },
      { id: "ORR_NQ_H1", label: "ORR_NQ_H1", note: "Higher TF", active: false },
      { id: "OSB_ES_15m", label: "OSB_ES_15m", note: "Scalp config", active: false },
      { id: "VWFT_CL_D1", label: "VWFT_CL_D1", note: "Crude swing", active: false }
    ]
  };
}

function fakeSuggestions() {
  return [
    {
      id: "s1",
      title: "Raise rrBandMin",
      field: "rrBandMin",
      from: 1.30,
      to: 1.50,
      impact: "More selective high R:R only",
      rating: "caution"
    },
    {
      id: "s2",
      title: "Reduce size in Chop",
      field: "maxSizeChop",
      from: 3,
      to: 2,
      impact: "Safer in choppy regimes",
      rating: "safer"
    },
    {
      id: "s3",
      title: "Tighten news lockout",
      field: "newsLockMinutes",
      from: 10,
      to: 15,
      impact: "Less exposure around events",
      rating: "safer"
    }
  ];
}

function fakeParams() {
  return [
    {
      name: "rrBandMin",
      current: 1.3,
      suggested: 1.5,
      impact: "More selective",
      impactType: "riskier",
      tooltip: "Minimum R:R to queue a ticket. Higher = fewer, higher quality trades."
    },
    {
      name: "rrBandMax",
      current: 2.3,
      suggested: 2.1,
      impact: "Take profits earlier",
      impactType: "safer",
      tooltip: "Upper bound for R:R used in scoring and size decisions."
    },
    {
      name: "stopTicks",
      current: 8,
      suggested: 10,
      impact: "Wider stop, safer",
      impactType: "safer",
      tooltip: "Default protective stop in ticks for this config."
    },
    {
      name: "ATRFloor",
      current: 4,
      suggested: 5,
      impact: "Skip micro sessions",
      impactType: "safer",
      tooltip: "Minimum ATR required to allow signals."
    },
    {
      name: "ATRFactor",
      current: 1.0,
      suggested: 1.2,
      impact: "Better vol alignment",
      impactType: "neutral",
      tooltip: "Scales stop/target by volatility."
    },
    {
      name: "maxSizeTrend",
      current: 3,
      suggested: 4,
      impact: "Higher size in trend",
      impactType: "riskier",
      tooltip: "Maximum contracts allowed in strong trend regimes."
    },
    {
      name: "maxSizeChop",
      current: 2,
      suggested: 2,
      impact: "Flat",
      impactType: "neutral",
      tooltip: "Maximum contracts allowed in chop regimes."
    }
  ];
}

function fakeBacktestSummary() {
  const baseWin = 62;
  const projWin = baseWin + 4 + Math.random()*2;
  const basePF = 1.8;
  const projPF = basePF + 0.2 + Math.random()*0.2;
  const baseDD = -3.2;
  const projDD = baseDD + 1 + Math.random()*0.3; // less negative

  return {
    period: "Last 60 sessions",
    winRateCur: baseWin.toFixed(1),
    winRateNew: projWin.toFixed(1),
    pfCur: basePF.toFixed(2),
    pfNew: projPF.toFixed(2),
    ddCur: baseDD.toFixed(1),
    ddNew: projDD.toFixed(1)
  };
}

function fakeEquityCurves(n = 40) {
  const cur = [];
  const proj = [];
  let p1 = 0;
  let p2 = 0;
  for (let i = 0; i < n; i++) {
    p1 += (Math.random() - 0.4) * 200;
    p2 += (Math.random() - 0.3) * 220;
    cur.push(p1);
    proj.push(p2);
  }
  return { cur, proj };
}

function fakeScenarios() {
  return [
    { name: "Trend Up (Strong)", state: "PASS" },
    { name: "Trend Down", state: "FAIL" },
    { name: "Chop Day", state: "PASS" },
    { name: "Volatility Spike", state: "WARN" }
  ];
}

// ---------- Rendering functions ----------

function renderConfigList(data) {
  const container = document.getElementById("config-list");
  const { configs, activeId } = data;
  container.innerHTML = "";

  configs.forEach(cfg => {
    const div = document.createElement("div");
    div.className = "rounded-md border px-3 py-2 mb-2 cursor-pointer transition text-[11px]";
    div.style.borderColor = "var(--border)";
    div.style.background = "var(--bg-panel)";
    if (cfg.id === activeId) {
      div.classList.add("config-active");
    }
    div.innerHTML = `
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-2">
          <span class="mono text-[11px]">${cfg.label}</span>
          ${cfg.id === activeId ? '<span class="text-[10px] px-1.5 py-0.5 rounded-full" style="background:var(--accent-soft);color:var(--accent);">Active</span>' : ""}
        </div>
        <div class="text-[10px]" style="color:var(--text-muted);">⋮</div>
      </div>
      <div class="text-[11px]" style="color:var(--text-muted);">${cfg.note}</div>
    `;
    container.appendChild(div);
  });
}

function renderSuggestions(list) {
  const container = document.getElementById("suggestions-list");
  container.innerHTML = "";

  list.forEach(item => {
    let badgeColor;
    if (item.rating === "safer") badgeColor = "var(--safer)";
    else if (item.rating === "caution") badgeColor = "var(--caution)";
    else badgeColor = "var(--text-secondary)";

    const div = document.createElement("div");
    div.className = "rounded-md border px-3 py-2 mb-2 cursor-pointer text-[11px] hover:bg-white/5 transition";
    div.style.borderColor = "var(--border)";
    div.innerHTML = `
      <div class="flex items-center justify-between mb-1">
        <div class="flex items-center gap-1">
          <span style="color:${badgeColor};">[!]</span>
          <span>${item.title}</span>
        </div>
        <span class="text-[10px]" style="color:${badgeColor};">Suggestion</span>
      </div>
      <div class="text-[10px]" style="color:var(--text-secondary);">
        <span class="mono">${item.field}</span>
        <span class="mx-1">·</span>
        <span class="mono">${item.from}</span>
        <span>→</span>
        <span class="mono">${item.to}</span>
      </div>
      <div class="text-[10px]" style="color:var(--text-muted);">${item.impact}</div>
    `;
    container.appendChild(div);
  });
}

function renderParamsTable(params) {
  const body = document.getElementById("params-rows");
  body.innerHTML = "";

  params.forEach((p, idx) => {
    const row = document.createElement("div");
    row.className = "grid grid-cols-[140px,80px,80px,120px,32px] px-3 py-1.5 border-b text-[11px]";
    row.style.borderColor = "var(--border)";
    if (idx < 2) {
      row.style.animation = "subtlePulse 3s ease-in-out infinite";
    }

    const impactClass =
      p.impactType === "safer"
        ? "impact-pill impact-safer"
        : p.impactType === "riskier"
        ? "impact-pill impact-riskier"
        : "impact-pill impact-neutral";

    const currentEdited = p.current !== p.suggested;
    const sugCellBorder = p.suggested !== null && p.suggested !== undefined ? "1px solid var(--accent)" : "1px solid var(--border)";

    row.innerHTML = `
      <div class="flex items-center gap-1">
        <span class="mono">${p.name}</span>
      </div>
      <div>
        <input type="text"
               value="${p.current}"
               class="w-full mono text-[11px] bg-transparent rounded border px-2 py-0.5"
               style="border-color:var(--border);color:var(--text);" />
      </div>
      <div>
        <input type="text"
               value="${p.suggested !== null ? p.suggested : ""}"
               class="w-full mono text-[11px] bg-transparent rounded px-2 py-0.5"
               style="border:${sugCellBorder};color:var(--text);" />
      </div>
      <div>
        <span class="${impactClass}">${p.impact}</span>
      </div>
      <div class="text-center" title="${p.tooltip}">
        <span style="color:var(--text-secondary);cursor:help;">?</span>
      </div>
    `;
    body.appendChild(row);
  });
}

function renderBacktestSummary(summary) {
  const el = document.getElementById("backtest-summary");
  const winDelta = summary.winRateNew - summary.winRateCur;
  const pfDelta = summary.pfNew - summary.pfCur;
  const ddDelta = summary.ddNew - summary.ddCur;

  function colorDelta(val, invert) {
    if (val === 0) return "var(--text-secondary)";
    if (!invert) {
      return val > 0 ? "var(--safer)" : "var(--riskier)";
    } else {
      return val < 0 ? "var(--safer)" : "var(--riskier)";
    }
  }

  el.innerHTML = `
    <div class="text-[11px] mb-1" style="color:var(--text-secondary);">
      Period: ${summary.period}
    </div>
    <div class="space-y-1 text-[11px]">
      <div class="flex justify-between">
        <span>Win Rate</span>
        <span class="mono">
          ${summary.winRateCur}% →
          <span style="color:${colorDelta(winDelta,false)};">${summary.winRateNew}%</span>
        </span>
      </div>
      <div class="flex justify-between">
        <span>Profit Factor</span>
        <span class="mono">
          ${summary.pfCur} →
          <span style="color:${colorDelta(pfDelta,false)};">${summary.pfNew}</span>
        </span>
      </div>
      <div class="flex justify-between">
        <span>Max Drawdown</span>
        <span class="mono">
          ${summary.ddCur}% →
          <span style="color:${colorDelta(ddDelta,true)};">${summary.ddNew}%</span>
        </span>
      </div>
    </div>
  `;
}

function renderEquityChart(curves) {
  const svg = document.getElementById("equity-chart");
  const width = 320;
  const height = 160;
  const padLeft = 24;
  const padRight = 8;
  const padTop = 10;
  const padBottom = 20;

  svg.setAttribute("viewBox", "0 0 " + width + " " + height);
  svg.setAttribute("preserveAspectRatio", "none");

  const allVals = curves.cur.concat(curves.proj);
  const minV = Math.min(...allVals);
  const maxV = Math.max(...allVals);
  const range = maxV - minV || 1;

  const innerWidth = width - padLeft - padRight;
  const innerHeight = height - padTop - padBottom;
  const stepCur = innerWidth / (curves.cur.length - 1);
  const stepProj = innerWidth / (curves.proj.length - 1);

  function y(v) {
    const n = (v - minV) / range;
    return padTop + (1 - n) * innerHeight;
  }

  let curPts = "";
  let projPts = "";

  curves.cur.forEach((v, i) => {
    const x = padLeft + i * stepCur;
    curPts += x + "," + y(v) + " ";
  });
  curves.proj.forEach((v, i) => {
    const x = padLeft + i * stepProj;
    projPts += x + "," + y(v) + " ";
  });

  svg.innerHTML = `
    <polyline points="${curPts.trim()}" fill="none"
              stroke="rgba(148,163,184,0.9)" stroke-width="1.3" />
    <polyline points="${projPts.trim()}" fill="none"
              stroke="var(--accent)" stroke-width="1.3" stroke-dasharray="4 3" />
  `;
}

function renderScenarios(list) {
  const container = document.getElementById("scenario-list");
  container.innerHTML = "";
  list.forEach(sc => {
    let color;
    if (sc.state === "PASS") color = "var(--safer)";
    else if (sc.state === "FAIL") color = "var(--riskier)";
    else color = "var(--caution)";

    const div = document.createElement("div");
    div.className = "flex items-center justify-between text-[11px] py-0.5";
    div.innerHTML = `
      <span>${sc.name}</span>
      <span class="mono" style="color:${color};">${sc.state}</span>
    `;
    container.appendChild(div);
  });
}

// ---------- Init ----------

document.addEventListener("DOMContentLoaded", () => {
  const cfgData = fakeConfigSets();
  const suggestions = fakeSuggestions();
  const params = fakeParams();
  const btSummary = fakeBacktestSummary();
  const curves = fakeEquityCurves(36);
  const scenarios = fakeScenarios();

  renderConfigList(cfgData);
  renderSuggestions(suggestions);
  renderParamsTable(params);
  renderBacktestSummary(btSummary);
  renderEquityChart(curves);
  renderScenarios(scenarios);
});
</script>

<div class="min-h-screen flex flex-col">

  <!-- STRATEGY LAB HEADER BAR -->
  <header class="px-6 py-3 border-b"
          style="background:var(--bg-header);border-color:var(--border);">
    <div class="flex items-center justify-between gap-4">
      <div class="flex items-center gap-3 flex-wrap text-[11px]">
        <button class="px-3 py-1 rounded-full border"
                style="border-color:var(--border);border-bottom:2px solid var(--accent);">
          Strategy: <span class="mono ml-1">ORR ▾</span>
        </button>
        <button class="px-3 py-1 rounded-full border"
                style="border-color:var(--border);">
          Symbol: <span class="mono ml-1">ES ▾</span>
        </button>
        <button class="px-3 py-1 rounded-full border"
                style="border-color:var(--border);">
          Config Set: <span class="mono ml-1">ORR_ES_D1 ▾</span>
        </button>

        <div class="flex items-center gap-1 ml-4">
          <span class="text-[11px]" style="color:var(--text-secondary);">Environment:</span>
          <button class="px-2 py-0.5 rounded-full border text-[11px] mono"
                  style="border-color:var(--border);background:var(--bg-panel);">
            Sim
          </button>
          <button class="px-2 py-0.5 rounded-full border text-[11px] mono"
                  style="border-color:var(--border);color:var(--text-muted);opacity:0.7;">
            Prod (read-only)
          </button>
        </div>
      </div>

      <div class="flex items-center gap-4 text-[11px]" style="color:var(--text-secondary);">
        <div>
          <span>State:</span>
          <span class="mono ml-1" style="color:var(--accent);">Saved</span>
        </div>
        <div>
          <span>Last Updated:</span>
          <span class="mono ml-1">09:52</span>
        </div>
        <button onclick="toggleTheme()"
                class="px-3 py-1 rounded-full border text-[11px]"
                style="border-color:var(--border);color:var(--text-secondary);">
          Theme
        </button>
      </div>
    </div>
  </header>

  <!-- MAIN 3-COLUMN GRID -->
  <main class="flex-1 px-6 py-4 flex gap-4">

    <!-- LEFT: CONFIG SETS + SUGGESTIONS -->
    <section class="w-[260px] flex-shrink-0 flex flex-col gap-3">
      <div class="rounded-lg border p-3"
           style="border-color:var(--border);background:var(--bg-panel);">
        <div class="flex items-center justify-between mb-2">
          <h2 class="text-[12px] font-semibold">Config Sets</h2>
          <button class="text-[11px]" style="color:var(--accent);">+ New</button>
        </div>
        <div id="config-list"></div>
      </div>

      <div class="rounded-lg border p-3 flex-1"
           style="border-color:var(--border);background:var(--bg-panel);">
        <div class="flex items-center justify-between mb-2">
          <h2 class="text-[12px] font-semibold">Suggestions</h2>
          <span class="text-[10px]" style="color:var(--text-secondary);">From engine</span>
        </div>
        <div id="suggestions-list"></div>
      </div>
    </section>

    <!-- CENTER: ACTIVE CONFIG EDITOR -->
    <section class="flex-1 rounded-lg border flex flex-col"
             style="border-color:var(--border);background:var(--bg-panel);">
      <div class="px-3 py-2 border-b flex items-center justify-between"
           style="border-color:var(--border);">
        <div>
          <h2 class="text-[12px] font-semibold">Active Config Editor</h2>
          <p class="text-[11px]" style="color:var(--text-secondary);">
            Adjust parameters, review suggestions and track impact.
          </p>
        </div>
        <div class="text-[10px]" style="color:var(--text-muted);">
          Config: <span class="mono">ORR_ES_D1</span>
        </div>
      </div>

      <!-- Param table header -->
      <div class="grid grid-cols-[140px,80px,80px,120px,32px] px-3 py-1.5 border-b text-[10px] font-medium"
           style="border-color:var(--border);color:var(--text-secondary);background:var(--bg-header);">
        <div>Param</div>
        <div class="text-left">Current</div>
        <div class="text-left">Suggested</div>
        <div>Impact</div>
        <div class="text-center">?</div>
      </div>

      <!-- Param rows -->
      <div id="params-rows" class="flex-1 overflow-auto"></div>

      <!-- Editor footer buttons -->
      <div class="px-3 py-3 border-t flex items-center justify-between gap-3"
           style="border-color:var(--border);background:var(--bg-header);">
        <div class="text-[10px]" style="color:var(--text-muted);">
          Changes are simulated only. Apply to mark config active.
        </div>
        <div class="flex items-center gap-2">
          <button class="px-3 py-1 rounded-full border text-[11px]"
                  style="border-color:var(--border);color:var(--accent);">
            Preview Impact
          </button>
          <button class="px-3 py-1 rounded-full border text-[11px]"
                  style="border-color:var(--accent);background:var(--accent);color:#020617;">
            Apply Changes
          </button>
          <button class="px-3 py-1 rounded-full border text-[11px]"
                  style="border-color:var(--border);color:var(--text-secondary);">
            Reset
          </button>
        </div>
      </div>
    </section>

    <!-- RIGHT: BACKTEST + IMPACT -->
    <section class="w-[320px] flex-shrink-0 flex flex-col gap-3">
      <div class="rounded-lg border p-3"
           style="border-color:var(--border);background:var(--bg-panel);">
        <div class="flex items-center justify-between mb-2">
          <h2 class="text-[12px] font-semibold">Backtest Results</h2>
          <span class="text-[10px]" style="color:var(--text-secondary);">Simulated</span>
        </div>
        <div id="backtest-summary" class="mb-3 text-[11px]"></div>
        <div class="rounded-md border overflow-hidden"
             style="border-color:var(--border);background:var(--bg-header);">
          <svg id="equity-chart" class="w-full h-32"></svg>
        </div>
      </div>

      <div class="rounded-lg border p-3 flex-1"
           style="border-color:var(--border);background:var(--bg-panel);">
        <div class="text-[12px] font-semibold mb-1">Scenario Tests</div>
        <div class="text-[11px] mb-2" style="color:var(--text-secondary);">
          Synthetic runs for common intraday regimes.
        </div>
        <div id="scenario-list" class="space-y-1"></div>
      </div>
    </section>

  </main>
</div>

</body>
</html>
EON

cat > server.js << 'EON'
const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = 3200;

const server = http.createServer((req, res) => {
  const filePath = path.join(process.cwd(), "index.html");

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(500, { "Content-Type": "text/plain" });
      res.end("Error loading index.html");
      return;
    }

    res.writeHead(200, { "Content-Type": "text/html" });
    res.end(data);
  });
});

server.listen(PORT, () => {
  console.log("=== Strategy Lab mock running at http://localhost:" + PORT + " ===");
});
EON

echo "=== STARTING STRATEGY LAB MOCK SERVER ON http://localhost:3200 ==="
node server.js
